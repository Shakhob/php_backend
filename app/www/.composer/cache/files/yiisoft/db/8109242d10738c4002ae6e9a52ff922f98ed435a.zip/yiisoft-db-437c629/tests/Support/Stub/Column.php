<?php

declare(strict_types=1);

namespace Yiisoft\Db\Tests\Support\Stub;

use Yiisoft\Db\Schema\Builder\AbstractColumn;

final class Column extends AbstractColumn
{
}
