<?php

declare(strict_types=1);

namespace Yiisoft\Db\Tests\Support\Stub;

use Yiisoft\Db\QueryBuilder\AbstractDQLQueryBuilder;

final class DQLQueryBuilder extends AbstractDQLQueryBuilder
{
}
