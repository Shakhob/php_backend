<?php

declare(strict_types=1);

namespace Yiisoft\Db\Tests\Support;

abstract class CompareValue
{
}
