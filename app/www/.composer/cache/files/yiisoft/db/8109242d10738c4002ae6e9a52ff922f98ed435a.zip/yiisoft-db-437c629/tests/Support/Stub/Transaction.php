<?php

declare(strict_types=1);

namespace Yiisoft\Db\Tests\Support\Stub;

use Yiisoft\Db\Driver\Pdo\AbstractPdoTransaction;

final class Transaction extends AbstractPdoTransaction
{
}
