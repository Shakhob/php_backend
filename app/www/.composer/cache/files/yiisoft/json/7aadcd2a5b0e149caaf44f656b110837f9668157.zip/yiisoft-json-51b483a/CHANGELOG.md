# JSON Change Log

## 1.0.0 August 26, 2020

- Initial release.
